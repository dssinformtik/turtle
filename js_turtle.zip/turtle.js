/** 2013 rev 2018 by thk, www.thkoehler.de 
Feel free to reuse this code provided this header remains intact.
**/

var anleitung=
"<b>Implementierte Befehle</b><br>"+
"aufxy(50,200) &rarr; Position (x,y) {oben ist y=0}<br>"+
"vw(100) &rarr; Vorw&auml;rtsschritte in aktuelle Richtung; rw(100) ~ <br>"+
"re(45) bzw. li(45) &rarr; Drehung um 45 Grad; re() dreht um 90 Grad <br>"+
"richtung(90) &rarr; nach oben erzwingen {0� zeigt nach rechts}<br>"+
"stift(255,0,0) oder stift(\"red\") oder stift(\"#ff0000\") &rarr; rot; allgemein (rot, gruen, blau) <br>"+
"pinsel(0,128,0) oder pinsel(\"darkgreen\") oder pinsel(\"#008000\") &rarr; auch Schrift<br>"+
"schreibe(\"blabla\",15,\"Arial\") oder schreibe(\"blabla\") Text an akt. Position<br>"+
"<br><b>Verwendung</b><br>schreibe deine Befehle in die function meineFunktion() unten in turtle.js",

NAV=navigator.appVersion, IEp=NAV.indexOf("MSIE"), 
		IE=((IEp>0)&&(Number(NAV.substr(IEp+5,2))<=9)), // IE tickt anders

Xw=900, Yw=600, // canvas Breite, Hoehe
		Xc=Xw/2, Yc=Yw/2, // cursor pos
		Richtg=0; // 0=Osten (rechts)
		Stift=1, // 0=ohne Stift bewegen, 1=zeichnen bei vw...
		HG="#f0f0f0",  // Hintergrundfarbe
		Sgroesse=16, SFarbe="black",

P180=Math.PI/180;

function aufxy(x,y){Xc=x; Yc=y;} // Zeichenposition setzen
	
function stift(r,g,b){
	if(g==undefined) document.getElementById("c1").getContext("2d").strokeStyle=r; else
	 document.getElementById("c1").getContext("2d").strokeStyle="rgb("+r+","+g+","+b+")";
	}

function pinsel(r,g,b){
	if(g==undefined){ document.getElementById("c1").getContext("2d").fillStyle=r; SFarbe=r;}
	else{ document.getElementById("c1").getContext("2d").fillStyle="rgb("+r+","+g+","+b+")"; SFarbe="rgb("+r+","+g+","+b+")";}
	HG=SFarbe;
	}

function init(){ // Standardwerte
	HG="#f0f0f0"; SFarbe="black"; Xc=Xw/2; Yc=Yw/2; Richtg=0;
	}

function li(a){if(!a) Richtg+=90; else Richtg+=a;}
function re(a){if(!a) Richtg-=90; else Richtg-=a;}

function richtung(a){Richtg=a;}

function schreibe(t,g,f){
	if(!g) g=Sgroesse; if(!f) f="Arial";
	var co=document.getElementById("c1").getContext("2d");
	co.fillStyle=SFarbe;
	co.font = g+"pt "+f;
	if(IE) co.font="normal "+g+"pt sans-serif";
	co.fillText(t,Math.round(Xc)-0.5,Math.round(Yc)-0.5);
	}

function vw(s){
var canvas = document.getElementById("c1"), co=canvas.getContext("2d");
  co.beginPath();
  co.moveTo(Math.round(Xc)+0.5, Math.round(Yc)+0.5);
  Xc+=s*Math.cos(Richtg*P180);
  Yc-=s*Math.sin(Richtg*P180);  
  if(Stift==1) co.lineTo(Math.round(Xc)+0.5, Math.round(Yc)+0.5);
  else co.moveTo(Math.round(Xc)+0.5, Math.round(Yc)+0.5);
  co.stroke();
  return true;
}

function rw(s){return vw(-s);}

function zeichne(){  // Beim Laden ausgefuehrt
init();
var canvas = document.getElementById("c1");
if(canvas.getContext){	
	var co = canvas.getContext("2d");
	co.fillStyle = HG; //"rgb(255, 0, 255)";
	co.fillRect(0, 0, canvas.width, canvas.height);
	meineFunktion();  //  <-- dein Code unten
	reset=0;
	}
}

function baum(l,w,t){
	vw(l); re(w); if(t>1) baum(l*0.7,w,t-1);
	li(2*w); if(t>1) baum(l*0.7,w,t-1);
	re(w); rw(l); stift(12*t,Math.max(0,255-30*t),5*t);
	}

function rdreieck(l,t){
for (var i=0; i<3; i++){
	vw(l); li(120); if(t>1) rdreieck(l/2,t-1);
	}
}

/** 
schreibe deinen Code in die nachfolgende function hinein, 
zwischen die geschweiften Klammern { ...und ...}  
**/

// zum einzeiligen Auskommentieren (deaktivieren) von Code

function meineFunktion(){
aufxy(10,550); rdreieck(600,8);
aufxy(550,600); li(); baum(180,29,16);

	} // Ende meineFunktion
	
	
function unbenutzt(){
/** verschiebe code hier hin, wenn er nicht ausgefuehrt werden sol **/
	pinsel(0,128,128); // (r, g, b), dunkel-cyan
	schreibe("Das ist ein Test",10); // Text in Groesse 10

	stift(0,128,0); // mittelgruen
	vw(200); re(); vw(100); re(); vw(200); re(); vw(100); 	// Rechteck:
	aufxy(50,100); richtung(0); stift("#darkorchid");
		for(var i=0; i<4; i++){
			vw(100); re();
			}
	// Kreis:
	aufxy(100,400); richtung(0); stift("#800040");
		for(var i=0; i<360; i++){
			vw(1); re(1);
			}

}

